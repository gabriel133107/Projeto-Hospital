// ================= VARIÁVEIS E INICIALIZAÇÃO ================= //
let usuariosCadastrados = JSON.parse(localStorage.getItem('clinica_v2_users')) || [];
let consultas = JSON.parse(localStorage.getItem('clinica_v2_consultas')) || [];

// Cria o Admin Padrão se o sistema estiver vazio
if (usuariosCadastrados.length === 0) {
    usuariosCadastrados = [
        { id: '1000', email: 'admin@clinica.com', senha: '123', perfil: 'admin', nome: 'Administrador do Sistema' }
    ];
    localStorage.setItem('clinica_v2_users', JSON.stringify(usuariosCadastrados));
}

let pacientes = usuariosCadastrados.filter(u => u.perfil === 'paciente');
let profissionais = usuariosCadastrados.filter(u => u.perfil === 'profissional');
let usuarioLogado = null;

// ================= UTILITÁRIOS ================= //
function mostrarToast(mensagem, tipo = 'sucesso') {
    const toast = document.getElementById('toast-notificacao');
    if (tipo === 'erro') {
        toast.classList.add('erro');
        toast.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${mensagem}`;
    } else {
        toast.classList.remove('erro');
        toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${mensagem}`;
    }
    toast.classList.remove('oculto');
    setTimeout(() => toast.classList.add('oculto'), 3500);
}

function mascaraCPF(input) {
    let value = input.value.replace(/\D/g, ''); 
    if (value.length > 11) value = value.slice(0, 11);
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    input.value = value;
}

function mascaraTelefone(input) {
    let value = input.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
    value = value.replace(/(\d{5})(\d)/, '$1-$2');
    input.value = value;
}

function atualizarBanco() {
    localStorage.setItem('clinica_v2_users', JSON.stringify(usuariosCadastrados));
    localStorage.setItem('clinica_v2_consultas', JSON.stringify(consultas));
    pacientes = usuariosCadastrados.filter(u => u.perfil === 'paciente');
    profissionais = usuariosCadastrados.filter(u => u.perfil === 'profissional');
}

// ================= NAVEGAÇÃO E ABAS ================= //
function mostrarAba(aba) {
    document.getElementById('aba-dashboard').classList.add('oculto');
    document.getElementById('aba-consultas').classList.add('oculto');
    document.getElementById('aba-pacientes').classList.add('oculto');
    document.getElementById('aba-profissionais').classList.add('oculto');
    
    document.getElementById('btn-nav-dashboard').classList.remove('ativo');
    document.getElementById('btn-nav-consultas').classList.remove('ativo');
    document.getElementById('btn-nav-pacientes').classList.remove('ativo');
    document.getElementById('btn-nav-profissionais').classList.remove('ativo');
    
    document.getElementById(`aba-${aba}`).classList.remove('oculto');
    document.getElementById(`btn-nav-${aba}`).classList.add('ativo');

    if(aba === 'dashboard') renderizarDashboard();
    if(aba === 'pacientes') renderizarPacientes();
    if(aba === 'profissionais') renderizarProfissionais();
    if(aba === 'consultas') renderizarConsultas();
}

// ================= LOGIN E CADASTRO ================= //
function mostrarCadastro(event) {
    if(event) event.preventDefault();
    document.getElementById('box-login').classList.add('oculto');
    document.getElementById('box-cadastro').classList.remove('oculto');
}

function mostrarLogin(event) {
    if(event) event.preventDefault();
    document.getElementById('box-cadastro').classList.add('oculto');
    document.getElementById('box-login').classList.remove('oculto');
}

function mudarCamposCadastro() {
    const perfil = document.getElementById('cad-perfil').value;
    const boxPaciente = document.getElementById('campos-paciente');
    const boxProfissional = document.getElementById('campos-profissional');
    
    document.getElementById('cad-cpf').required = false;
    document.getElementById('cad-telefone').required = false;
    document.getElementById('cad-nascimento').required = false;
    document.getElementById('cad-registro').required = false;
    document.getElementById('cad-especialidade').required = false;

    boxPaciente.classList.add('oculto');
    boxProfissional.classList.add('oculto');

    if (perfil === 'paciente') {
        boxPaciente.classList.remove('oculto');
        document.getElementById('cad-cpf').required = true;
        document.getElementById('cad-telefone').required = true;
        document.getElementById('cad-nascimento').required = true;
    } else if (perfil === 'profissional') {
        boxProfissional.classList.remove('oculto');
        document.getElementById('cad-registro').required = true;
        document.getElementById('cad-especialidade').required = true;
    }
}

function realizarCadastro(event) {
    event.preventDefault();
    const email = document.getElementById('cad-email').value.trim().toLowerCase();
    
    if (usuariosCadastrados.some(user => user.email === email)) {
        return mostrarToast("E-mail já cadastrado!", "erro");
    }

    const novoUsuario = { 
        id: Math.floor(1000 + Math.random() * 9000).toString(),
        email: email, 
        senha: document.getElementById('cad-senha').value, 
        perfil: document.getElementById('cad-perfil').value, 
        nome: document.getElementById('cad-nome').value.trim(),
        cpf: document.getElementById('cad-cpf').value,
        telefone: document.getElementById('cad-telefone').value,
        nascimento: document.getElementById('cad-nascimento').value,
        registro: document.getElementById('cad-registro').value,
        especialidade: document.getElementById('cad-especialidade').value
    };

    usuariosCadastrados.push(novoUsuario);
    atualizarBanco();
    mostrarToast("Conta criada com sucesso! Faça login para acessar.");
    document.getElementById('form-cadastro').reset();
    mostrarLogin();
}

function realizarLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-usuario').value.trim().toLowerCase();
    const senha = document.getElementById('login-senha').value;
    const perfil = document.getElementById('login-perfil').value;

    const user = usuariosCadastrados.find(u => u.email === email);

    if (!user) return mostrarToast("Usuário não encontrado!", "erro");
    if (user.senha !== senha) return mostrarToast("Senha incorreta!", "erro");
    if (user.perfil !== perfil) return mostrarToast("O perfil selecionado não corresponde à sua conta!", "erro");

    usuarioLogado = user;
    document.getElementById('tela-login').classList.add('oculto');
    document.getElementById('conteudo-sistema').classList.remove('oculto');

    let labelPerfil = user.perfil === 'admin' ? 'Administrador' : user.perfil === 'profissional' ? 'Médico' : 'Paciente';
    let icone = user.perfil === 'admin' ? 'fa-user-tie' : user.perfil === 'profissional' ? 'fa-user-doctor' : 'fa-user';
    
    document.getElementById('nome-usuario-logado').innerHTML = `
        <div class="avatar-icon"><i class="fa-solid ${icone}"></i></div>
        <span><strong>${user.nome}</strong><br><small style="font-size:0.75rem; opacity:0.8;">${labelPerfil}</small></span>
    `;

    mostrarToast(`Bem-vindo(a), ${user.nome}!`);
    aplicarPermissoes(user.perfil);
    carregarSelects();
    renderizarConsultas();
}

function realizarLogout() {
    usuarioLogado = null;
    document.getElementById('login-senha').value = '';
    document.getElementById('conteudo-sistema').classList.add('oculto');
    document.getElementById('tela-login').classList.remove('oculto');
}

function aplicarPermissoes(perfil) {
    const bPac = document.getElementById('btn-nav-pacientes');
    const bProf = document.getElementById('btn-nav-profissionais');

    bPac.style.display = (perfil === 'admin' || perfil === 'profissional') ? 'inline-block' : 'none';
    bProf.style.display = (perfil === 'admin') ? 'inline-block' : 'none';
    
    // Abre direto no Dashboard ao logar
    mostrarAba('dashboard');
}

// ================= RENDERIZAÇÕES E DASHBOARD ================= //
function renderizarDashboard() {
    const hoje = new Date().toISOString().split('T')[0];

    let consultasVisiveis = consultas;
    if (usuarioLogado.perfil === 'paciente') {
        consultasVisiveis = consultas.filter(c => c.idPaciente === usuarioLogado.id);
    } else if (usuarioLogado.perfil === 'profissional') {
        consultasVisiveis = consultas.filter(c => c.idProfissional === usuarioLogado.id);
    }

    const consultasHoje = consultasVisiveis.filter(c => c.data === hoje && c.situacao !== 'Cancelada');
    const totalAgendadas = consultasVisiveis.filter(c => c.situacao === 'Agendada').length;

    document.getElementById('dash-consultas-hoje').textContent = consultasHoje.length;
    document.getElementById('dash-consultas-agendadas').textContent = totalAgendadas;
    document.getElementById('dash-total-pacientes').textContent = pacientes.length;
    document.getElementById('dash-total-profissionais').textContent = profissionais.length;

    const tbody = document.getElementById('tabela-dashboard-hoje');
    tbody.innerHTML = '';

    if (consultasHoje.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#888;">Nenhuma consulta agendada para hoje.</td></tr>`;
        return;
    }

    consultasHoje.sort((a, b) => a.horario.localeCompare(b.horario));

    consultasHoje.forEach(c => {
        const nomePac = pacientes.find(p => p.id === c.idPaciente)?.nome || 'Paciente';
        const nomeProf = profissionais.find(p => p.id === c.idProfissional)?.nome || 'Profissional';
        
        tbody.innerHTML += `
            <tr>
                <td><strong>${c.horario}</strong></td>
                <td>${nomePac}</td>
                <td>${nomeProf}</td>
                <td>${c.especialidade}</td>
                <td><span class="badge badge-agendada">${c.situacao}</span></td>
            </tr>
        `;
    });
}

function carregarSelects() {
    const selPaciente = document.getElementById('cons-paciente');
    const selProfissional = document.getElementById('cons-profissional');
    
    selPaciente.innerHTML = '<option value="">Selecione o paciente...</option>';
    selProfissional.innerHTML = '<option value="">Selecione o profissional...</option>';

    if(usuarioLogado.perfil === 'paciente') {
        selPaciente.innerHTML += `<option value="${usuarioLogado.id}" selected>${usuarioLogado.nome}</option>`;
        selPaciente.disabled = true;
    } else {
        selPaciente.disabled = false;
        pacientes.forEach(p => selPaciente.innerHTML += `<option value="${p.id}">${p.nome} (CPF: ${p.cpf})</option>`);
    }

    if(usuarioLogado.perfil === 'profissional') {
        selProfissional.innerHTML += `<option value="${usuarioLogado.id}" selected>${usuarioLogado.nome} - ${usuarioLogado.especialidade}</option>`;
        selProfissional.disabled = true;
    } else {
        selProfissional.disabled = false;
        profissionais.forEach(p => selProfissional.innerHTML += `<option value="${p.id}">${p.nome} - ${p.especialidade}</option>`);
    }
}

function renderizarConsultas() {
    const tbody = document.getElementById('tabela-consultas');
    const termo = document.getElementById('pesquisa-consulta').value.toLowerCase();
    tbody.innerHTML = '';

    let filtradas = consultas;

    if (usuarioLogado.perfil === 'paciente') {
        filtradas = consultas.filter(c => c.idPaciente === usuarioLogado.id);
    } else if (usuarioLogado.perfil === 'profissional') {
        filtradas = consultas.filter(c => c.idProfissional === usuarioLogado.id);
    }

    if (termo) {
        filtradas = filtradas.filter(c => {
            const pac = pacientes.find(p => p.id === c.idPaciente)?.nome.toLowerCase() || '';
            const prof = profissionais.find(p => p.id === c.idProfissional)?.nome.toLowerCase() || '';
            return pac.includes(termo) || prof.includes(termo) || c.situacao.toLowerCase().includes(termo);
        });
    }

    filtradas.sort((a, b) => new Date(b.data) - new Date(a.data));

    filtradas.forEach(c => {
        const nomePac = pacientes.find(p => p.id === c.idPaciente)?.nome || 'Paciente excluído';
        const nomeProf = profissionais.find(p => p.id === c.idProfissional)?.nome || 'Profissional excluído';
        
        let badgeClass = 'badge-agendada';
        if (c.situacao === 'Realizada') badgeClass = 'badge-realizada';
        if (c.situacao === 'Cancelada') badgeClass = 'badge-cancelada';

        const dataFormatada = c.data.split('-').reverse().join('/');

        tbody.innerHTML += `
            <tr>
                <td>#${c.id}</td>
                <td>${nomePac}</td>
                <td>${nomeProf}</td>
                <td>${c.especialidade}</td>
                <td>${dataFormatada}</td>
                <td>${c.horario}</td>
                <td><span class="badge ${badgeClass}">${c.situacao}</span></td>
                <td>${c.observacao || '-'}</td>
                <td class="acoes-td">
                    <button class="btn-acao btn-edit" title="Editar" onclick="editarConsulta('${c.id}')"><i class="fa-solid fa-pen"></i></button>
                    ${c.situacao !== 'Cancelada' ? `<button class="btn-acao btn-delete" title="Cancelar" onclick="cancelarConsulta('${c.id}')"><i class="fa-solid fa-ban"></i></button>` : ''}
                </td>
            </tr>
        `;
    });
}

function renderizarPacientes() {
    const tbody = document.getElementById('tabela-pacientes');
    const termo = document.getElementById('pesquisa-paciente').value.toLowerCase();
    tbody.innerHTML = '';

    let filtrados = pacientes;
    if (termo) {
        filtrados = pacientes.filter(p => (p.nome && p.nome.toLowerCase().includes(termo)) || (p.cpf && p.cpf.includes(termo)));
    }

    filtrados.forEach(p => {
        tbody.innerHTML += `
            <tr>
                <td>#${p.id}</td>
                <td>${p.nome}</td>
                <td>${p.cpf || '-'}</td>
                <td>${p.nascimento ? p.nascimento.split('-').reverse().join('/') : '-'}</td>
                <td>${p.telefone || '-'}</td>
                <td class="acoes-td">
                    <button class="btn-acao btn-edit" onclick="editarUsuario('${p.id}')"><i class="fa-solid fa-pen"></i></button>
                </td>
            </tr>
        `;
    });
}

function renderizarProfissionais() {
    const tbody = document.getElementById('tabela-profissionais');
    const termo = document.getElementById('pesquisa-profissional').value.toLowerCase();
    tbody.innerHTML = '';

    let filtrados = profissionais;
    if (termo) {
        filtrados = profissionais.filter(p => (p.nome && p.nome.toLowerCase().includes(termo)) || (p.especialidade && p.especialidade.toLowerCase().includes(termo)));
    }

    filtrados.forEach(p => {
        tbody.innerHTML += `
            <tr>
                <td>#${p.id}</td>
                <td>${p.nome}</td>
                <td>${p.especialidade || '-'}</td>
                <td>${p.telefone || '-'}</td>
                <td class="acoes-td">
                    <button class="btn-acao btn-edit" onclick="editarUsuario('${p.id}')"><i class="fa-solid fa-pen"></i></button>
                </td>
            </tr>
        `;
    });
}

// ================= AGENDAMENTO E EDIÇÃO ================= //
function salvarConsulta(event) {
    event.preventDefault();
    const idConsulta = document.getElementById('cons-id').value;
    const idPaciente = document.getElementById('cons-paciente').value;
    const idProfissional = document.getElementById('cons-profissional').value;
    const data = document.getElementById('cons-data').value;
    const horario = document.getElementById('cons-horario').value;
    const situacao = document.getElementById('cons-situacao').value;
    const observacao = document.getElementById('cons-observacao').value;

    const hoje = new Date().toISOString().split('T')[0];
    if (data < hoje) {
        return mostrarToast("Data inválida. Não é possível agendar no passado.", "erro");
    }

    const conflito = consultas.find(c => 
        c.idProfissional === idProfissional && 
        c.data === data && 
        c.horario === horario && 
        c.id !== idConsulta && 
        c.situacao !== 'Cancelada'
    );

    if (conflito) {
        return mostrarToast("Não foi possível realizar o agendamento. Já existe uma consulta marcada para este profissional nesse horário.", "erro");
    }

    const prof = profissionais.find(p => p.id === idProfissional);

    if (idConsulta) {
        let index = consultas.findIndex(c => c.id === idConsulta);
        consultas[index] = { ...consultas[index], idPaciente, idProfissional, especialidade: prof.especialidade, data, horario, situacao, observacao };
        mostrarToast("Consulta atualizada com sucesso!");
    } else {
        consultas.push({
            id: Math.floor(10000 + Math.random() * 90000).toString(),
            idPaciente, idProfissional, especialidade: prof.especialidade, data, horario, situacao, observacao
        });
        mostrarToast("Consulta agendada com sucesso!");
    }

    atualizarBanco();
    document.getElementById('form-consulta').reset();
    document.getElementById('cons-id').value = "";
    document.getElementById('btn-salvar-consulta').innerHTML = `<i class="fa-solid fa-calendar-check"></i> Salvar Agendamento`;
    renderizarConsultas();
}

function editarConsulta(id) {
    const c = consultas.find(c => c.id === id);
    if(c) {
        document.getElementById('cons-id').value = c.id;
        document.getElementById('cons-paciente').value = c.idPaciente;
        document.getElementById('cons-profissional').value = c.idProfissional;
        document.getElementById('cons-data').value = c.data;
        document.getElementById('cons-horario').value = c.horario;
        document.getElementById('cons-situacao').value = c.situacao;
        document.getElementById('cons-observacao').value = c.observacao || '';
        document.getElementById('btn-salvar-consulta').innerHTML = `<i class="fa-solid fa-pen"></i> Atualizar Agendamento`;
        window.scrollTo(0, 0);
    }
}

function cancelarConsulta(id) {
    if(confirm("Deseja realmente cancelar esta consulta?")) {
        let index = consultas.findIndex(c => c.id === id);
        consultas[index].situacao = 'Cancelada';
        atualizarBanco();
        renderizarConsultas();
        mostrarToast("Consulta cancelada com sucesso.");
    }
}

// ================= EDIÇÃO DE USUÁRIOS (MODAL) ================= //
function editarUsuario(id) {
    const user = usuariosCadastrados.find(u => u.id === id);
    if (!user) return;

    document.getElementById('edit-id').value = user.id;
    document.getElementById('edit-perfil').value = user.perfil;
    document.getElementById('edit-nome').value = user.nome;
    document.getElementById('edit-telefone').value = user.telefone || '';

    const divPac = document.getElementById('edit-campos-paciente');
    const divProf = document.getElementById('edit-campos-profissional');
    
    divPac.classList.add('oculto');
    divProf.classList.add('oculto');

    if (user.perfil === 'paciente') {
        divPac.classList.remove('oculto');
        document.getElementById('edit-cpf').value = user.cpf || '';
        document.getElementById('edit-nascimento').value = user.nascimento || '';
    } else if (user.perfil === 'profissional') {
        divProf.classList.remove('oculto');
        document.getElementById('edit-especialidade').value = user.especialidade || '';
    }

    document.getElementById('modal-edicao').classList.remove('oculto');
}

function fecharModalEdicao() {
    document.getElementById('modal-edicao').classList.add('oculto');
}

function salvarEdicaoUsuario(event) {
    event.preventDefault();
    const id = document.getElementById('edit-id').value;
    const perfil = document.getElementById('edit-perfil').value;
    
    const index = usuariosCadastrados.findIndex(u => u.id === id);
    if (index === -1) return;

    usuariosCadastrados[index].nome = document.getElementById('edit-nome').value.trim();
    usuariosCadastrados[index].telefone = document.getElementById('edit-telefone').value;

    if (perfil === 'paciente') {
        usuariosCadastrados[index].cpf = document.getElementById('edit-cpf').value;
        usuariosCadastrados[index].nascimento = document.getElementById('edit-nascimento').value;
    } else if (perfil === 'profissional') {
        usuariosCadastrados[index].especialidade = document.getElementById('edit-especialidade').value;
    }

    atualizarBanco();
    fecharModalEdicao();
    mostrarToast("Cadastro atualizado com sucesso!");

    if (perfil === 'paciente') renderizarPacientes();
    if (perfil === 'profissional') renderizarProfissionais();
    carregarSelects();
    renderizarConsultas();
}